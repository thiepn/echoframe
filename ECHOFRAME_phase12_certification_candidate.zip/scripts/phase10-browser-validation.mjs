import path from 'node:path';
import { rm } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import {
  ROOT, assert, startStaticServer, launchBrowser, waitForGame, waitForScene, waitUntil,
  activateButton, capture, diagnostics, resetToMenu, startRunDirect, completeAcceleratedRun,
  writeJson, sleep,
} from './phase10-browser-helpers.mjs';

const dist = path.join(ROOT, 'dist-validation');
await rm(dist, { recursive: true, force: true });
execFileSync(process.execPath, [path.join(ROOT, 'node_modules/vite/bin/vite.js'), 'build', '--mode', 'validation', '--outDir', 'dist-validation'], {
  cwd: ROOT, stdio: 'inherit', env: { ...process.env, VITE_BASE_PATH: '/' },
});
const server = await startStaticServer({ directory: dist, base: '/' });
const runtime = await launchBrowser({ engine: 'chromium', viewport: { width: 1600, height: 900 } });
const { browser, page, errors, warnings, exceptions, failedRequests } = runtime;
const checks = {}; const observations = {};
try {
  const response = await page.goto(`${server.url}?debug=1`, { waitUntil: 'networkidle' });
  checks.http200 = response?.status() === 200;
  await waitForGame(page); await waitForScene(page, 'MainMenuScene');
  checks.title = await page.title() === 'ECHOFRAME: LAST SIGNAL';
  checks.releaseMode = (await page.evaluate(() => globalThis.__ECHOFRAME__.getReleaseSnapshot().mode)) === 'validation';
  await resetToMenu(page, { clearSave: true });
  const fresh = await diagnostics(page);
  checks.freshTutorialIncomplete = fresh.save.meta.tutorialCompleted === false;
  checks.freshRunCountZero = fresh.save.statistics.aggregateCounters.runsStarted === 0;
  await capture(page, 'ECHOFRAME_phase10_main_menu.png');

  await activateButton(page, 'MainMenuScene', 0); await waitForScene(page, 'TutorialScene');
  checks.freshRoutesTutorial = true;
  checks.noRunCreatedBeforeTutorial = !(await diagnostics(page)).runActive;
  await page.keyboard.down('d'); await sleep(90); await page.keyboard.up('d');
  await waitUntil(page, () => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__?.snapshot().state === 'MOVE_CHECKPOINTS');
  await capture(page, 'ECHOFRAME_phase10_tutorial_movement.png');

  await page.keyboard.press('Escape'); await waitForScene(page, 'PauseScene');
  checks.tutorialPause = true; await activateButton(page, 'PauseScene', 0); await waitForScene(page, 'TutorialScene');
  checks.tutorialResume = true;

  await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.advanceTo('AIM_AND_FIRE'));
  const target = await page.evaluate(() => { const s = globalThis.__ECHOFRAME__.game.scene.getScene('TutorialScene'); return { x: s.stationaryTarget.x, y: s.stationaryTarget.y }; });
  const canvas = await page.locator('canvas').boundingBox();
  if (canvas) {
    await page.mouse.move(canvas.x + target.x * canvas.width / 1600, canvas.y + target.y * canvas.height / 900);
    await page.mouse.down({ button: 'left' }); await sleep(180); await page.mouse.up({ button: 'left' });
    await sleep(900);
  }
  const afterFire = await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.snapshot().state);
  checks.realPointerFireAccepted = afterFire === 'DASH_GATE';
  if (!checks.realPointerFireAccepted) await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.advanceTo('DASH_GATE'));

  await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.advanceTo('DEPLOY_ECHO'));
  const echoVisual = await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.forceEchoVisual());
  checks.productionEchoDeployed = echoVisual.deployed && echoVisual.fireEvents >= 4;
  await sleep(250); await capture(page, 'ECHOFRAME_phase10_tutorial_echo.png');
  await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.forceEchoSuccess());
  await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.complete());
  await waitForScene(page, 'RunScene', 30000);
  const postTutorial = await diagnostics(page);
  checks.completionPersisted = postTutorial.save.meta.tutorialCompleted === true;
  checks.oneRunStarted = postTutorial.save.statistics.aggregateCounters.runsStarted === 1;
  checks.tutorialScoreExcluded = postTutorial.save.records.recentRuns.length === 0 && postTutorial.save.statistics.aggregateCounters.totalScore === 0;
  checks.combatOneStarts = postTutorial.activeScenes.includes('RunScene');

  await resetToMenu(page);
  await activateButton(page, 'MainMenuScene', 0); await waitForScene(page, 'RunScene');
  checks.returningBypassesTutorial = !(await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScenes(true).some((s) => s.scene.key === 'TutorialScene')));
  await resetToMenu(page);
  const recordsBeforeReplay = (await diagnostics(page)).save.records.recentRuns.length;
  await activateButton(page, 'MainMenuScene', 3); await waitForScene(page, 'ArchiveScene');
  const archiveButtonCount = await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('ArchiveScene').buttons.length);
  await activateButton(page, 'ArchiveScene', archiveButtonCount - 2); await waitForScene(page, 'TutorialScene');
  checks.archiveReplayEntry = true;
  await page.evaluate(() => globalThis.__ECHOFRAME_PHASE10_TUTORIAL__.complete()); await waitForScene(page, 'ArchiveScene');
  const recordsAfterReplay = (await diagnostics(page)).save.records.recentRuns.length;
  checks.archiveReplayNoRunRecord = recordsAfterReplay === recordsBeforeReplay;

  await resetToMenu(page); await activateButton(page, 'MainMenuScene', 5); await waitForScene(page, 'SettingsScene');
  await activateButton(page, 'SettingsScene', 3); await sleep(100);
  await capture(page, 'ECHOFRAME_phase10_controls_rebinding.png');
  const revisionBefore = (await diagnostics(page)).input.bindingRevision;
  await activateButton(page, 'SettingsScene', 0); await sleep(200); await page.keyboard.press('i'); await sleep(180);
  let bindings = await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('SettingsScene').services.settingsManager.get('controls.bindings'));
  checks.keyboardRebind = bindings.moveUp[0].code === 'KeyI';
  checks.immediateContextRebuild = (await diagnostics(page)).input.bindingRevision > revisionBefore;
  await activateButton(page, 'SettingsScene', 2); await sleep(200); await page.keyboard.press('i'); await sleep(180);
  bindings = await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('SettingsScene').services.settingsManager.get('controls.bindings'));
  checks.conflictRejected = bindings.moveDown[0].code === 'KeyS';
  await activateButton(page, 'SettingsScene', 8); await sleep(220);
  if (canvas) await page.mouse.click(canvas.x + 800 * canvas.width / 1600, canvas.y + 450 * canvas.height / 900, { button: 'middle' });
  await sleep(180);
  bindings = await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('SettingsScene').services.settingsManager.get('controls.bindings'));
  checks.pointerRebind = bindings.fire[0].device === 'pointer' && bindings.fire[0].button === 1;
  await activateButton(page, 'SettingsScene', 0); await sleep(200); await page.keyboard.press('Escape'); await sleep(150);
  checks.escapeCancelsCapture = !(await diagnostics(page)).input.captureActive;
  await activateButton(page, 'SettingsScene', 16); await sleep(120);
  bindings = await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('SettingsScene').services.settingsManager.get('controls.bindings'));
  checks.restoreDefaults = bindings.moveUp[0].code === 'KeyW' && bindings.fire[0].button === 0 && bindings.dash[1].button === 2;

  await page.reload({ waitUntil: 'networkidle' }); await waitForGame(page); await waitForScene(page, 'MainMenuScene');
  const reloaded = await diagnostics(page);
  checks.reloadPersistence = reloaded.save.meta.tutorialCompleted === true && reloaded.save.settings.controls.bindings.moveUp[0].code === 'KeyW';

  await activateButton(page, 'MainMenuScene', 5); await waitForScene(page, 'SettingsScene'); await activateButton(page, 'SettingsScene', 2); await sleep(120);
  await capture(page, 'ECHOFRAME_phase10_accessibility.png');
  checks.accessibilityPage = (await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('SettingsScene').section)) === 'accessibility';
  await resetToMenu(page); await activateButton(page, 'MainMenuScene', 6); await waitForScene(page, 'CreditsScene'); await capture(page, 'ECHOFRAME_phase10_credits.png');
  checks.credits = true;

  await startRunDirect(page, 'standard', 40101);
  await page.evaluate(() => { globalThis.__ECHOFRAME_PHASE9__.setCombo(12); globalThis.__ECHOFRAME_PHASE9__.spawnFullRoster(); globalThis.__ECHOFRAME_PHASE9__.forceRecordingReady(); globalThis.__ECHOFRAME_PHASE9__.forceCooldownReady(); globalThis.__ECHOFRAME_PHASE9__.deployEcho(); });
  await sleep(500); await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('RunScene').services.debugManager.setEnabled(false)); await sleep(60); await capture(page, 'ECHOFRAME_phase10_full_combat.png');
  await page.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('RunScene').services.debugManager.setEnabled(true));
  checks.combatRegression = true;
  const route = await completeAcceleratedRun(page, {
    difficultyId: 'standard', seed: 40102, result: 'victory',
    screenshotCallback: async (currentPage, stage) => {
      if (stage === 'boss') {
        await currentPage.evaluate(() => { globalThis.__ECHOFRAME_PHASE9__.forcePhase('DELETE'); const scene = globalThis.__ECHOFRAME__.game.scene.getScene('BossScene'); scene.services.debugManager.setEnabled(false); });
        await sleep(220); await capture(currentPage, 'ECHOFRAME_phase10_boss_phase3.png');
        await currentPage.evaluate(() => globalThis.__ECHOFRAME__.game.scene.getScene('BossScene').services.debugManager.setEnabled(true));
      }
      if (stage === 'results') await capture(currentPage, 'ECHOFRAME_phase10_results.png');
    },
  });
  checks.fullRouteVictory = route.result === 'victory' && route.recentRuns > 0;
  observations.route = route;

  await resetToMenu(page); await page.evaluate(() => globalThis.__ECHOFRAME__.triggerFatal('EF-VALIDATION-FATAL')); await page.waitForSelector('#fatal-error-screen');
  await capture(page, 'ECHOFRAME_phase10_fatal_screen.png');
  const fatal = await page.evaluate(() => ({ text: document.querySelector('#fatal-error-screen')?.innerText ?? '', stack: document.querySelector('#fatal-error-screen')?.innerText?.includes(' at ') ?? false }));
  checks.fatalScreen = fatal.text.includes('EF-VALIDATION-FATAL') && fatal.text.includes('Reload') && fatal.text.includes('Clear Local Data') && !fatal.stack;

  observations.finalDiagnostics = await page.evaluate(() => ({ title: document.title, fatalVisible: Boolean(document.querySelector('#fatal-error-screen')) }));
  checks.zeroExceptions = exceptions.length === 0;
  checks.zeroConsoleErrors = errors.length === 0;
  checks.zeroFailedRequests = failedRequests.length === 0;
  checks.warningsExplained = warnings.every((item) => /AudioContext|WebGL|GPU/i.test(item.text));
} finally {
  await browser.close(); await server.close();
}
const report = {
  generatedAt: new Date().toISOString(), browser: 'Chromium', engineExecutable: process.env.CHROMIUM_EXECUTABLE ?? 'Playwright-managed',
  base: '/', checks, observations, exceptions, consoleErrors: errors, consoleWarnings: warnings, failedRequests,
  requestCount: server.requests.length, passed: Object.values(checks).every(Boolean),
};
await writeJson('PHASE10_BROWSER_CHROMIUM_VALIDATION.json', report);
console.log(JSON.stringify({ passed: report.passed, checks, exceptions: exceptions.length, consoleErrors: errors.length, warnings: warnings.length, failedRequests: failedRequests.length }, null, 2));
if (!report.passed) process.exitCode = 1;
